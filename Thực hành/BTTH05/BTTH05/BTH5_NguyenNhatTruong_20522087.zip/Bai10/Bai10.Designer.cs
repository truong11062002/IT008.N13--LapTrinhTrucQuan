﻿
namespace Bai10
{
    partial class Bai10
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox_DashStyle = new System.Windows.Forms.ComboBox();
            this.comboBox_Width = new System.Windows.Forms.ComboBox();
            this.comboBox_LineJoin = new System.Windows.Forms.ComboBox();
            this.comboBox_DashCap = new System.Windows.Forms.ComboBox();
            this.comboBox_StartCap = new System.Windows.Forms.ComboBox();
            this.comboBox_EndCap = new System.Windows.Forms.ComboBox();
            this.pictureBox_showPen = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_showPen)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(12, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(113, 25);
            this.label1.TabIndex = 0;
            this.label1.Text = "Dash Style:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(12, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(69, 25);
            this.label2.TabIndex = 1;
            this.label2.Text = "Width:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(12, 163);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 25);
            this.label3.TabIndex = 2;
            this.label3.Text = "Line Join:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(12, 227);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(106, 25);
            this.label4.TabIndex = 3;
            this.label4.Text = "Dash Cap:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(12, 288);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 25);
            this.label5.TabIndex = 4;
            this.label5.Text = "Start Cap:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 349);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(95, 25);
            this.label6.TabIndex = 5;
            this.label6.Text = "End Cap:";
            // 
            // comboBox_DashStyle
            // 
            this.comboBox_DashStyle.FormattingEnabled = true;
            this.comboBox_DashStyle.Location = new System.Drawing.Point(131, 33);
            this.comboBox_DashStyle.Name = "comboBox_DashStyle";
            this.comboBox_DashStyle.Size = new System.Drawing.Size(129, 24);
            this.comboBox_DashStyle.TabIndex = 6;
            // 
            // comboBox_Width
            // 
            this.comboBox_Width.FormattingEnabled = true;
            this.comboBox_Width.Location = new System.Drawing.Point(131, 95);
            this.comboBox_Width.Name = "comboBox_Width";
            this.comboBox_Width.Size = new System.Drawing.Size(129, 24);
            this.comboBox_Width.TabIndex = 8;
            this.comboBox_Width.Text = "1";
            // 
            // comboBox_LineJoin
            // 
            this.comboBox_LineJoin.FormattingEnabled = true;
            this.comboBox_LineJoin.Location = new System.Drawing.Point(131, 167);
            this.comboBox_LineJoin.Name = "comboBox_LineJoin";
            this.comboBox_LineJoin.Size = new System.Drawing.Size(129, 24);
            this.comboBox_LineJoin.TabIndex = 9;
            // 
            // comboBox_DashCap
            // 
            this.comboBox_DashCap.FormattingEnabled = true;
            this.comboBox_DashCap.Location = new System.Drawing.Point(131, 231);
            this.comboBox_DashCap.Name = "comboBox_DashCap";
            this.comboBox_DashCap.Size = new System.Drawing.Size(129, 24);
            this.comboBox_DashCap.TabIndex = 10;
            // 
            // comboBox_StartCap
            // 
            this.comboBox_StartCap.FormattingEnabled = true;
            this.comboBox_StartCap.Location = new System.Drawing.Point(131, 292);
            this.comboBox_StartCap.Name = "comboBox_StartCap";
            this.comboBox_StartCap.Size = new System.Drawing.Size(129, 24);
            this.comboBox_StartCap.TabIndex = 11;
            // 
            // comboBox_EndCap
            // 
            this.comboBox_EndCap.FormattingEnabled = true;
            this.comboBox_EndCap.Location = new System.Drawing.Point(131, 353);
            this.comboBox_EndCap.Name = "comboBox_EndCap";
            this.comboBox_EndCap.Size = new System.Drawing.Size(129, 24);
            this.comboBox_EndCap.TabIndex = 12;
            // 
            // pictureBox_showPen
            // 
            this.pictureBox_showPen.Location = new System.Drawing.Point(339, 9);
            this.pictureBox_showPen.Name = "pictureBox_showPen";
            this.pictureBox_showPen.Size = new System.Drawing.Size(442, 429);
            this.pictureBox_showPen.TabIndex = 13;
            this.pictureBox_showPen.TabStop = false;
            this.pictureBox_showPen.Paint += new System.Windows.Forms.PaintEventHandler(this.pictureBox_showPen_Paint);
            this.pictureBox_showPen.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pictureBox_showPen_MouseDown);
            this.pictureBox_showPen.MouseMove += new System.Windows.Forms.MouseEventHandler(this.pictureBox_showPen_MouseMove);
            this.pictureBox_showPen.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pictureBox_showPen_MouseUp);
            // 
            // Bai10
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox_showPen);
            this.Controls.Add(this.comboBox_EndCap);
            this.Controls.Add(this.comboBox_StartCap);
            this.Controls.Add(this.comboBox_DashCap);
            this.Controls.Add(this.comboBox_LineJoin);
            this.Controls.Add(this.comboBox_Width);
            this.Controls.Add(this.comboBox_DashStyle);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Bai10";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pen demo";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_showPen)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox_DashStyle;
        private System.Windows.Forms.ComboBox comboBox_Width;
        private System.Windows.Forms.ComboBox comboBox_LineJoin;
        private System.Windows.Forms.ComboBox comboBox_DashCap;
        private System.Windows.Forms.ComboBox comboBox_StartCap;
        private System.Windows.Forms.ComboBox comboBox_EndCap;
        private System.Windows.Forms.PictureBox pictureBox_showPen;
    }
}

