﻿
namespace Bai07
{
    partial class movie
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_chon = new System.Windows.Forms.Button();
            this.pn = new System.Windows.Forms.Panel();
            this.btn_15 = new System.Windows.Forms.Button();
            this.btn_10 = new System.Windows.Forms.Button();
            this.btn_5 = new System.Windows.Forms.Button();
            this.btn_14 = new System.Windows.Forms.Button();
            this.btn_9 = new System.Windows.Forms.Button();
            this.btn_4 = new System.Windows.Forms.Button();
            this.btn_13 = new System.Windows.Forms.Button();
            this.btn_8 = new System.Windows.Forms.Button();
            this.btn_3 = new System.Windows.Forms.Button();
            this.btn_12 = new System.Windows.Forms.Button();
            this.btn_7 = new System.Windows.Forms.Button();
            this.btn_2 = new System.Windows.Forms.Button();
            this.btn_11 = new System.Windows.Forms.Button();
            this.btn_6 = new System.Windows.Forms.Button();
            this.btn_1 = new System.Windows.Forms.Button();
            this.btn_huybo = new System.Windows.Forms.Button();
            this.btn_KetThuc = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txt_money = new System.Windows.Forms.TextBox();
            this.pn.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_chon
            // 
            this.btn_chon.Location = new System.Drawing.Point(139, 419);
            this.btn_chon.Name = "btn_chon";
            this.btn_chon.Size = new System.Drawing.Size(119, 49);
            this.btn_chon.TabIndex = 0;
            this.btn_chon.Text = "Chọn";
            this.btn_chon.UseVisualStyleBackColor = true;
            this.btn_chon.Click += new System.EventHandler(this.onClick_Chon);
            // 
            // pn
            // 
            this.pn.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.pn.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pn.Controls.Add(this.btn_15);
            this.pn.Controls.Add(this.btn_10);
            this.pn.Controls.Add(this.btn_5);
            this.pn.Controls.Add(this.btn_14);
            this.pn.Controls.Add(this.btn_9);
            this.pn.Controls.Add(this.btn_4);
            this.pn.Controls.Add(this.btn_13);
            this.pn.Controls.Add(this.btn_8);
            this.pn.Controls.Add(this.btn_3);
            this.pn.Controls.Add(this.btn_12);
            this.pn.Controls.Add(this.btn_7);
            this.pn.Controls.Add(this.btn_2);
            this.pn.Controls.Add(this.btn_11);
            this.pn.Controls.Add(this.btn_6);
            this.pn.Controls.Add(this.btn_1);
            this.pn.Location = new System.Drawing.Point(139, 149);
            this.pn.Name = "pn";
            this.pn.Size = new System.Drawing.Size(488, 189);
            this.pn.TabIndex = 3;
            // 
            // btn_15
            // 
            this.btn_15.BackColor = System.Drawing.Color.White;
            this.btn_15.Location = new System.Drawing.Point(387, 127);
            this.btn_15.Name = "btn_15";
            this.btn_15.Size = new System.Drawing.Size(90, 54);
            this.btn_15.TabIndex = 14;
            this.btn_15.Text = "15";
            this.btn_15.UseVisualStyleBackColor = false;
            // 
            // btn_10
            // 
            this.btn_10.BackColor = System.Drawing.Color.White;
            this.btn_10.Location = new System.Drawing.Point(387, 67);
            this.btn_10.Name = "btn_10";
            this.btn_10.Size = new System.Drawing.Size(90, 54);
            this.btn_10.TabIndex = 13;
            this.btn_10.Text = "10";
            this.btn_10.UseVisualStyleBackColor = false;
            // 
            // btn_5
            // 
            this.btn_5.BackColor = System.Drawing.Color.White;
            this.btn_5.Location = new System.Drawing.Point(387, 7);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(90, 54);
            this.btn_5.TabIndex = 12;
            this.btn_5.Text = "5";
            this.btn_5.UseVisualStyleBackColor = false;
            // 
            // btn_14
            // 
            this.btn_14.BackColor = System.Drawing.Color.White;
            this.btn_14.Location = new System.Drawing.Point(291, 127);
            this.btn_14.Name = "btn_14";
            this.btn_14.Size = new System.Drawing.Size(90, 54);
            this.btn_14.TabIndex = 11;
            this.btn_14.Text = "14";
            this.btn_14.UseVisualStyleBackColor = false;
            // 
            // btn_9
            // 
            this.btn_9.BackColor = System.Drawing.Color.White;
            this.btn_9.Location = new System.Drawing.Point(291, 67);
            this.btn_9.Name = "btn_9";
            this.btn_9.Size = new System.Drawing.Size(90, 54);
            this.btn_9.TabIndex = 10;
            this.btn_9.Text = "9";
            this.btn_9.UseVisualStyleBackColor = false;
            // 
            // btn_4
            // 
            this.btn_4.BackColor = System.Drawing.Color.White;
            this.btn_4.Location = new System.Drawing.Point(291, 7);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(90, 54);
            this.btn_4.TabIndex = 9;
            this.btn_4.Text = "4";
            this.btn_4.UseVisualStyleBackColor = false;
            // 
            // btn_13
            // 
            this.btn_13.BackColor = System.Drawing.Color.White;
            this.btn_13.Location = new System.Drawing.Point(195, 127);
            this.btn_13.Name = "btn_13";
            this.btn_13.Size = new System.Drawing.Size(90, 54);
            this.btn_13.TabIndex = 8;
            this.btn_13.Text = "13";
            this.btn_13.UseVisualStyleBackColor = false;
            // 
            // btn_8
            // 
            this.btn_8.BackColor = System.Drawing.Color.White;
            this.btn_8.Location = new System.Drawing.Point(195, 67);
            this.btn_8.Name = "btn_8";
            this.btn_8.Size = new System.Drawing.Size(90, 54);
            this.btn_8.TabIndex = 7;
            this.btn_8.Text = "8";
            this.btn_8.UseVisualStyleBackColor = false;
            // 
            // btn_3
            // 
            this.btn_3.BackColor = System.Drawing.Color.White;
            this.btn_3.Location = new System.Drawing.Point(195, 7);
            this.btn_3.Name = "btn_3";
            this.btn_3.Size = new System.Drawing.Size(90, 54);
            this.btn_3.TabIndex = 6;
            this.btn_3.Text = "3";
            this.btn_3.UseVisualStyleBackColor = false;
            // 
            // btn_12
            // 
            this.btn_12.BackColor = System.Drawing.Color.White;
            this.btn_12.Location = new System.Drawing.Point(99, 127);
            this.btn_12.Name = "btn_12";
            this.btn_12.Size = new System.Drawing.Size(90, 54);
            this.btn_12.TabIndex = 5;
            this.btn_12.Text = "12";
            this.btn_12.UseVisualStyleBackColor = false;
            // 
            // btn_7
            // 
            this.btn_7.BackColor = System.Drawing.Color.White;
            this.btn_7.Location = new System.Drawing.Point(99, 67);
            this.btn_7.Name = "btn_7";
            this.btn_7.Size = new System.Drawing.Size(90, 54);
            this.btn_7.TabIndex = 4;
            this.btn_7.Text = "7";
            this.btn_7.UseVisualStyleBackColor = false;
            // 
            // btn_2
            // 
            this.btn_2.BackColor = System.Drawing.Color.White;
            this.btn_2.Location = new System.Drawing.Point(99, 7);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(90, 54);
            this.btn_2.TabIndex = 3;
            this.btn_2.Text = "2";
            this.btn_2.UseVisualStyleBackColor = false;
            // 
            // btn_11
            // 
            this.btn_11.BackColor = System.Drawing.Color.White;
            this.btn_11.Location = new System.Drawing.Point(3, 127);
            this.btn_11.Name = "btn_11";
            this.btn_11.Size = new System.Drawing.Size(90, 54);
            this.btn_11.TabIndex = 2;
            this.btn_11.Text = "11";
            this.btn_11.UseVisualStyleBackColor = false;
            // 
            // btn_6
            // 
            this.btn_6.BackColor = System.Drawing.Color.White;
            this.btn_6.Location = new System.Drawing.Point(3, 67);
            this.btn_6.Name = "btn_6";
            this.btn_6.Size = new System.Drawing.Size(90, 54);
            this.btn_6.TabIndex = 1;
            this.btn_6.Text = "6";
            this.btn_6.UseVisualStyleBackColor = false;
            // 
            // btn_1
            // 
            this.btn_1.BackColor = System.Drawing.Color.White;
            this.btn_1.Location = new System.Drawing.Point(3, 7);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(90, 54);
            this.btn_1.TabIndex = 0;
            this.btn_1.Text = "1";
            this.btn_1.UseVisualStyleBackColor = false;
            // 
            // btn_huybo
            // 
            this.btn_huybo.Location = new System.Drawing.Point(324, 419);
            this.btn_huybo.Name = "btn_huybo";
            this.btn_huybo.Size = new System.Drawing.Size(119, 49);
            this.btn_huybo.TabIndex = 4;
            this.btn_huybo.Text = "Hủy bỏ";
            this.btn_huybo.UseVisualStyleBackColor = true;
            this.btn_huybo.Click += new System.EventHandler(this.onClick_HuyBo);
            // 
            // btn_KetThuc
            // 
            this.btn_KetThuc.Location = new System.Drawing.Point(508, 419);
            this.btn_KetThuc.Name = "btn_KetThuc";
            this.btn_KetThuc.Size = new System.Drawing.Size(119, 49);
            this.btn_KetThuc.TabIndex = 5;
            this.btn_KetThuc.Text = "Kết thúc";
            this.btn_KetThuc.UseVisualStyleBackColor = true;
            this.btn_KetThuc.Click += new System.EventHandler(this.onClick_KetThuc);
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(6, 6);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(756, 64);
            this.panel2.TabIndex = 6;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.OrangeRed;
            this.label1.Location = new System.Drawing.Point(311, 15);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(150, 32);
            this.label1.TabIndex = 0;
            this.label1.Text = "MÀN ẢNH";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(174, 376);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(115, 25);
            this.label2.TabIndex = 8;
            this.label2.Text = "Thành tiền";
            // 
            // txt_money
            // 
            this.txt_money.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_money.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_money.Location = new System.Drawing.Point(304, 375);
            this.txt_money.Name = "txt_money";
            this.txt_money.ReadOnly = true;
            this.txt_money.Size = new System.Drawing.Size(289, 27);
            this.txt_money.TabIndex = 9;
            this.txt_money.Text = "0";
            this.txt_money.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // movie
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(766, 506);
            this.Controls.Add(this.txt_money);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btn_KetThuc);
            this.Controls.Add(this.btn_huybo);
            this.Controls.Add(this.pn);
            this.Controls.Add(this.btn_chon);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "movie";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.pn.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_chon;
        private System.Windows.Forms.Panel pn;
        private System.Windows.Forms.Button btn_15;
        private System.Windows.Forms.Button btn_10;
        private System.Windows.Forms.Button btn_5;
        private System.Windows.Forms.Button btn_14;
        private System.Windows.Forms.Button btn_9;
        private System.Windows.Forms.Button btn_4;
        private System.Windows.Forms.Button btn_13;
        private System.Windows.Forms.Button btn_8;
        private System.Windows.Forms.Button btn_3;
        private System.Windows.Forms.Button btn_12;
        private System.Windows.Forms.Button btn_7;
        private System.Windows.Forms.Button btn_2;
        private System.Windows.Forms.Button btn_11;
        private System.Windows.Forms.Button btn_6;
        private System.Windows.Forms.Button btn_1;
        private System.Windows.Forms.Button btn_huybo;
        private System.Windows.Forms.Button btn_KetThuc;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txt_money;
    }
}

